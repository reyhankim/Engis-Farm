//
// Created by reyha on 27/02/2019.
//

#ifndef ENGISFARM_FARMPRODUCT_HPP
#define ENGISFARM_FARMPRODUCT_HPP


#include "Product.hpp"

// Class FarmProduct adalah Product yang dihasilkan oleh FarmAnimal
class FarmProduct : Product {
    public:
        //Ctor
        FarmProduct();
};


#endif //ENGISFARM_FARMPRODUCT_HPP
